const div = document.getElementById("myDiv");
div.addEventListener("click", function asd () {
  alert("Hola! Soy el div");
});

function handleClick() {
  alert("Hola!");
}
